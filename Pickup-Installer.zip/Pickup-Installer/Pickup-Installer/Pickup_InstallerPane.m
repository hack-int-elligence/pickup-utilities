//
//  Pickup_InstallerPane.m
//  Pickup-Installer
//
//  Created by Jacob Kahn on 9/5/15.
//  Copyright (c) 2015 Jacob Kahn. All rights reserved.
//

#import "Pickup_InstallerPane.h"

@interface Pickup_InstallerPane()

@property (weak) IBOutlet NSTextField *userNameTextField;
@property (strong) IBOutlet NSSecureTextField *passwordTextField;


@end

@implementation Pickup_InstallerPane

- (NSString *)title
{
	return [[NSBundle bundleForClass:[self class]] localizedStringForKey:@"PaneTitle" value:nil table:nil];
}

@end
