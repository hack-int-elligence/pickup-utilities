//
//  Pickup_InstallerPane.h
//  Pickup-Installer
//
//  Created by Jacob Kahn on 9/5/15.
//  Copyright (c) 2015 Jacob Kahn. All rights reserved.
//

#import <InstallerPlugins/InstallerPlugins.h>

@interface Pickup_InstallerPane : InstallerPane

@end
